The "lib" directory is intended to hold Jar files which this module is dependent upon.  Jar files 
may be placed in this directory manually, or automatically by maven via the dependencies block
of this module's build.gradle file.